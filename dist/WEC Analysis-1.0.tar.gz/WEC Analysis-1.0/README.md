[![author](https://img.shields.io/badge/author-feliperoll-purple.svg)](https://www.linkedin.com/in/felipe-roll/)

### 󠁧󠁢󠁥󠁮󠁧EN 
# Inspired by: https://github.com/JaideepGuntupalli/f1-predictor?tab=readme-ov-file
&nbsp;
# Project Overview:
&nbsp;
# Code and Resources used:
  ### Python Version: 3.9.13
  ### Packages:
&nbsp;
# Data Cleaning:
&nbsp;

# Data Collection & Exploratory Data Analysis:
&nbsp;
# Links:
  
 - https://www.youtube.com/watch?v=agHKuUoMwvY&list=PL2zq7klxX5ASFejJj80ob9ZAnBHdz5O1t&index=7
 - https://github.com/JaideepGuntupalli/f1-predictor?tab=readme-ov-file#developed-by
 - https://github.com/ikatyang/emoji-cheat-sheet/blob/master/README.md
 - https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax
&nbsp;
# Developed by: [Felipe Roll](https://www.linkedin.com/in/felipe-roll/)


__________________________________________________________________________________________________________________________________________________________________________________________________________________
__________________________________________________________________________________________________________________________________________________________________________________________________________________



### :brazil:
# Inspirado por: https://github.com/JaideepGuntupalli/f1-predictor?tab=readme-ov-file
&nbsp;  
# Visão geral do projeto:
&nbsp;
# Código e Recursos Utilizados:
  ### Versão Python: 3.9.13
  ### Pacotes:
   
&nbsp;      
# Limpeza de Dados:
&nbsp;
# Coleta de Dados e Análise exploratória de Dados:
&nbsp;
# Links:
  
 - https://www.youtube.com/watch?v=agHKuUoMwvY&list=PL2zq7klxX5ASFejJj80ob9ZAnBHdz5O1t&index=7
 - https://github.com/JaideepGuntupalli/f1-predictor?tab=readme-ov-file#developed-by
 - https://github.com/ikatyang/emoji-cheat-sheet/blob/master/README.md
 - https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax
&nbsp;
# Desenvolvido por: [Felipe Roll](https://www.linkedin.com/in/felipe-roll-7290a811b/)

    

  

  

